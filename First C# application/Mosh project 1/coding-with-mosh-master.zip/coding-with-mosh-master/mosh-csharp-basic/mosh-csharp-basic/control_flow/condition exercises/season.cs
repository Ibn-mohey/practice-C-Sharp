﻿using System;

namespace mosh_csharp_basic.control_flow
{

    public enum Season
    {
        Spring,
        Summer,
        Autumn,
        Winter
    }
}

﻿using System;
using System.Globalization;

namespace mosh_csharp_basic.working_with_dates
{
    class timespan_exercise
    {
        
        public void timeSpanExercise()
        {
            //C# Sharp Exercises: Display the number of ticks TimeSpan object using the Ticks property

            //Write a C# Sharp program to display the number of ticks that have elapsed since the beginning of the twenty-first century 
            //and to instantiate a TimeSpan object using the Ticks property.

            //Note: The TimeSpan object is then used to display the elapsed time using several other time intervals.
            
            

        }
    }
}


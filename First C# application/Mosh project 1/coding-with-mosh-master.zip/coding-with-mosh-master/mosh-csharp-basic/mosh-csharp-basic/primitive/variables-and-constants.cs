﻿using System;

namespace mosh_csharp_basic.primitive
{
    class Variables_and_constants
    {
        public void CSharpVaribaleAndConstants()
        {
            //byte number = 2;
            //var count = 10;
            //float totalPrice = 20.95f;
            //char character = 'A';
            //string firstName = "Peter";
            //bool isWorking = false;

            //Console.WriteLine(count);
            //Console.WriteLine(totalPrice);
            //Console.WriteLine(character);
            //Console.WriteLine(firstName);
            //Console.WriteLine(isWorking);
            //Console.WriteLine(number);

            //Console.WriteLine("{0} {1}", byte.MinValue, byte.MaxValue);
            //Console.WriteLine("{0} {1}", float.MinValue, float.MaxValue);

            const float Pi = 3.12f;
        }
    }
}

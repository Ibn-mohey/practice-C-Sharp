﻿using System;

namespace mosh_csharp_basic.primitive
{
    public class HelloWorld
    {

        public void CSharpHelloWorld()
        {
            Console.WriteLine("HelloWorld");
        }
    }
}

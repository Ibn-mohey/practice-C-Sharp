﻿using System;

namespace mosh_csharp_basic.nonprimitive.classes
{
    public class ReferenceType
    {
        public int Age;
    }
}

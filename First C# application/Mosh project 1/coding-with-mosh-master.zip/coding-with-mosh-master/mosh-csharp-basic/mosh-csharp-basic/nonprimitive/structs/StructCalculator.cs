﻿using System;

namespace mosh_csharp_basic.nonprimitive
{
    public class StructCalculator
    {
        public int Add(int a, int b)
        {
            return a + b;
        }

        //public static int Add(int a, int b)
        //{
        //    return a + b;
        //}
    }
}

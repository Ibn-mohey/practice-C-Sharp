﻿using System;

namespace mosh_csharp_basic.nonprimitive
{
    public enum ShippingMethod
    {
        RegularAirMail = 1,
        RegisteredAirMail = 2,
        Express = 3
    }
}

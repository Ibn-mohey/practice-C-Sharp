﻿namespace Polymorphism
{
    public class Mail
    {
    }
}
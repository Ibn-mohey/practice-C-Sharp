﻿namespace Polymorphism
{
    public class Video
    {
    }
}
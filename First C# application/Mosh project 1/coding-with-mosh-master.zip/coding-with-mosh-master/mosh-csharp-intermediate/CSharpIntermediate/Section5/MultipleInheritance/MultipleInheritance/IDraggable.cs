﻿namespace MultipleInheritance
{
    public interface IDraggable
    {
        void Drag();
    }
}
﻿namespace Amazon
{
    internal class RateCalculator
    {
        public int Calculate(Customer customer)
        {
            return 0;
        }
    }
}
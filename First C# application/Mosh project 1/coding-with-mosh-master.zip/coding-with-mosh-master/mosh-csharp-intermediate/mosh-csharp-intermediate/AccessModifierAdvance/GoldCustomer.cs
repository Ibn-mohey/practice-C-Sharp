﻿//namespace mosh_csharp_intermediate.AccessModifierAdvance
//{
//    public class GoldCustomer : Customer
//    {
//        public void OfferVoucher()
//        {
//            var rating = this.CalculateRating(excludeOrders: true);
//        }
//    }
//}
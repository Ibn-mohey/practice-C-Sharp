﻿using Amazon;

namespace mosh_csharp_intermediate.AccessModifierAdvance
{
    class Program
    {
        static void Main(string[] args)
        {
            var customer = new Customer();

            //Amazon.RateCalculator calculator = new RateCalculator();
        }
    }
}

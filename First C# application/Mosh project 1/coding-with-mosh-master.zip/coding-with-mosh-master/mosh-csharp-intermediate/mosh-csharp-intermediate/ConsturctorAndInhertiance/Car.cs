﻿using System;

namespace mosh_csharp_intermediate.ConstructorAndInhertiance
{
    public class Car : Vehicle
    {
        public Car()
        {
            Console.WriteLine("Car is being initialized");
        }
    }
}
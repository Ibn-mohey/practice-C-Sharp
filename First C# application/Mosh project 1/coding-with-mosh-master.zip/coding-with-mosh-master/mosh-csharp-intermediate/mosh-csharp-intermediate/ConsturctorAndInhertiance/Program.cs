﻿namespace mosh_csharp_intermediate.ConstructorAndInhertiance
{
    class Program
    {
        static void Main(string[] args)
        {
            var car = new Car();
        }
    }
}

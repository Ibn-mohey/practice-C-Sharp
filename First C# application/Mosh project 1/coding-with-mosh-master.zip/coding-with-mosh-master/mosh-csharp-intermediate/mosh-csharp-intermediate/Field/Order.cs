﻿namespace mosh_csharp_intermediate.Field
{
    public class Order
    {
    }
}
﻿ using System;

namespace mosh_csharp_intermediate.Composition
{
    public class Logger
    {
        public void Log(string message)
        {
            Console.WriteLine(message);
        }
    }
}